Fenner — Test de Orientación TP (Responsive + Tema + Kiosko)
=====================================================================

Novedades
---------
• Tema claro/oscuro con botón (persistente).
• Modo Kiosko: pantalla completa + UI XL (fuentes, radios, botones) con persistencia.
• Mantiene: preguntas obligatorias, curso 2° A–G, Top 3, semáforo, envío por Apps Script.
• Sin botón de exportar JSON. Subtítulo agregado bajo el título.

Uso rápido
----------
1) Apps Script (backend):
   - Drive → Nuevo → Google Apps Script → pega `apps-script/Code.gs`.
   - (Opcional) Manifiesto: `apps-script/appsscript.json` (timeZone America/Santiago).
   - Implementar → Implementar como aplicación web → Ejecutar como: Tu usuario; Acceso: Cualquiera con el enlace.
   - Copia la URL que termina en /exec.

2) Frontend:
   - Abre `index.html` y reemplaza:
       const EMAIL_ENDPOINT = "YOUR_WEB_APP_URL_HERE";
     por la URL /exec.
   - Abre `index.html` en el navegador o súbelo a tu hosting.

Atajos
------
• 🌙/☀️ Tema: alterna claro/oscuro.
• 🖥️ Kiosko: activa pantalla completa y UI XL. 🗗 Salir Kiosko para volver.
• Imprimir/Guardar PDF con diseño responsive.

Notas técnicas
--------------
• fetch(...,{mode:"no-cors"}) evita CORS; revisa entregas en Apps Script → Ejecuciones.
• Variables CSS controlan colores (dark/light) y tamaños (kiosk).
• Personaliza umbrales del semáforo en `renderResults` y ponderaciones en `calcular`.
